# issues

Sus Testvragen:
De besturing van het spel is makkelijk te begrijpen.
Ik zou me kunnen vermaken met het spelen van dit spel.
Het doel van het spel is duidelijk.
het spel zelf is niet te lastig
het spel is niet te makkelijk
het spel ziet er netjes uit
het spel hield mijn aandacht erbij
het spel duurde niet te lang
het spel duurde niet te kort
het spel is geschikt voor mijn doelgroep(middelbare scholier)





